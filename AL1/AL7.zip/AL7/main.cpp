#include <Novice.h>

const char kWindowTitle[] = "AL7-1";

// Windowsアプリでのエントリーポイント(main関数)
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {

	// ライブラリの初期化
	Novice::Initialize(kWindowTitle, 1280, 720);

	// キー入力結果を受け取る箱
	char keys[256] = { 0 };
	char preKeys[256] = { 0 };

	//変数宣言
	
	//自分の情報
	float posX = 100.0f;
	float posY = 100.0f;
	float speed = 7.0f;
	float radius = 10.0f;
	float timer = 15.0f;

	//　リソース画像

	//　後ろ向きの画像
	int buck0 = Novice::LoadTexture("./images./buck0.png");
	int buck1 = Novice::LoadTexture("./images./buck1.png");
	int buck2 = Novice::LoadTexture("./images./buck2.png");
	int buck3 = Novice::LoadTexture("./images./buck3.png");

	// 前向きの画像
	int flont0 = Novice::LoadTexture("./images./flont0.png");
	int flont1 = Novice::LoadTexture("./images./flont1.png");
	int flont2 = Novice::LoadTexture("./images./flont2.png");
	int flont3 = Novice::LoadTexture("./images./flont3.png");

	//　左向きの画像
	int left0 = Novice::LoadTexture("./images./left0.png");
	int left1 = Novice::LoadTexture("./images./left1.png");
	int left2 = Novice::LoadTexture("./images./left2.png");
	int left3 = Novice::LoadTexture("./images./left3.png");

	//　右向きの画像
	int right0 = Novice::LoadTexture("./images./right0.png");
	int right1 = Novice::LoadTexture("./images./right1.png");
	int right2 = Novice::LoadTexture("./images./right2.png");
	int right3 = Novice::LoadTexture("./images./right3./png");

	// ウィンドウの×ボタンが押されるまでループ
	while (Novice::ProcessMessage() == 0) {
		// フレームの開始
		Novice::BeginFrame();

		// キー入力を受け取る
		memcpy(preKeys, keys, 256);
		Novice::GetHitKeyStateAll(keys);

		///
		/// ↓更新処理ここから
		///

		//　移動処理
		if (keys[DIK_W]) {
			posY = posY - speed;
		}

		if (keys[DIK_S]) {
			posY = posY + speed;
		}

		if (keys[DIK_A]) {
			posX = posX - speed;
		}

		if (keys[DIK_D]) {
			posX = posX + speed;
		}

		//　画面外に出ない様にする処理
		if (posY >= 710) {
			posY = posY - 7;
		}

		if (posY <= 10) {
			posY = posY + 7;
		}

		if (posX >= 1270) {
			posX = posX - 7;
		}

		if (posX <= 10) {
			posX = posX + 7;
		}

		///
		/// ↑更新処理ここまで
		///

		///
		/// ↓描画処理ここから
		///
		if (DIK_S&&timer >= 15) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, flont0, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_S&&timer >= 30) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, flont1, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_S&&timer >= 45) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, flont2, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_S&&timer >= 60) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, flont3, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_W && timer >= 15) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, buck0, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_W && timer >= 30) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, buck1, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_W && timer >= 45) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, buck2, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_W && timer >= 60) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, buck3, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_A && timer >= 15) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, left0, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_A && timer >= 30) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, left1, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_A && timer >= 45) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, left2, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_A && timer >= 60) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, left3, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_D && timer >= 15) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, right0, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_D && timer >= 30) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, right1, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_D && timer >= 45) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, right2, 1.0f, 1.0f, 0.0f, WHITE);
		}

		if (DIK_D && timer >= 60) {
			Novice::DrawSprite((int)posX - (int)radius, (int)posY - (int)radius, right3, 1.0f, 1.0f, 0.0f, WHITE);
		}
		///
		/// ↑描画処理ここまで
		///

		// フレームの終了
		Novice::EndFrame();

		// ESCキーが押されたらループを抜ける
		if (preKeys[DIK_ESCAPE] == 0 && keys[DIK_ESCAPE] != 0) {
			break;
		}
	}

	// ライブラリの終了
	Novice::Finalize();
	return 0;
}
